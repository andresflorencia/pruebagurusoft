﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace pruebaflorencia.Models
{
    [Table("Producto")]
    public partial class Producto
    {
        [Key]
        [Column("idproducto")]
        public long Idproducto { get; set; }
        [Required]
        [Column("codigo")]
        [StringLength(100)]
        public string Codigo { get; set; }
        [Required]
        [Column("producto")]
        [DisplayName("Nombre producto")]
        [StringLength(100)]
        public string Producto1 { get; set; }
        [Column("descripcion")]
        [DisplayName("Descripción")]
        [StringLength(250)]
        public string Descripcion { get; set; }
        [Column("precio", TypeName = "decimal(18, 4)")]
        public decimal Precio { get; set; }
        [Column("cantidad")]
        public int Cantidad { get; set; }
        [Column("total", TypeName = "decimal(18, 4)")]
        public decimal Total { get; set; }
        [Column("fechaingreso", TypeName = "datetime")]
        [DisplayName("Fecha de Ingreso")]
        public DateTime Fechaingreso { get; set; }
    }
}
