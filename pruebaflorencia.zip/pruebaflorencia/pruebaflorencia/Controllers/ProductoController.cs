﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using pruebaflorencia.Models;
using Microsoft.AspNetCore.Authorization;

namespace pruebaflorencia.Controllers
{
    [Authorize]
    public class ProductoController : Controller
    {
        public IActionResult Index()
        {
            IEnumerable<Producto> lista = new List<Producto>();
            using(var context = new PruebaFlorenciaContext())
            {
                lista = (from d in context.Productos
                         select d).ToList();
            }
            return View(lista);
        }

        public IActionResult New()
        {
            ViewBag.message = "";
            return View();
        }

        public IActionResult Save(Producto modelo)
        {
            using(var context = new PruebaFlorenciaContext())
            {
                context.Add(modelo);
                context.SaveChanges();
                ViewBag.message = "Producto guardado correctamente";
            }
            return View("New",modelo);
        }

        public IActionResult Details(int id = 0)
        {
            var producto = new Producto();
            using(var context = new PruebaFlorenciaContext())
            {
                producto = (from d in context.Productos
                            where d.Idproducto == id
                            select d).FirstOrDefault();
            }
            return View(producto);
        }

        public IActionResult Edit(int id = 0)
        {
            var producto = new Producto();
            using (var context = new PruebaFlorenciaContext())
            {
                producto = (from d in context.Productos
                            where d.Idproducto == id
                            select d).FirstOrDefault();
            }
            return View(producto);
        }

        public IActionResult Update(Producto producto)
        {
            using(var context = new PruebaFlorenciaContext())
            {
                context.Entry(producto).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                context.SaveChanges();
                ViewBag.message = "Producto modificado correctamente";
            }
            return View("Edit", producto);
        }

        public IActionResult Delete(int id = 0)
        {
            IEnumerable<Producto> lista = new List<Producto>();
            using (PruebaFlorenciaContext context = new PruebaFlorenciaContext())
            {
                context.Entry(new Producto() { Idproducto = id }).State = Microsoft.EntityFrameworkCore.EntityState.Deleted;
                context.SaveChanges();
                ViewBag.message = "Producto eliminado correctamente.";

                lista = (from d in context.Productos
                           select d).ToList();
            }
            return View("Index", lista);
        }
    }
}
